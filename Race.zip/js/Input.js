//ARROW KEYS
const KEY_LEFT_ARROW = 37;
const KEY_UP_ARROW = 38;
const KEY_RIGHT_ARROW = 39;
const KEY_DOWN_ARROW = 40;

//WASD KEYS
const KEY_W = 87;
const KEY_A = 65;
const KEY_S = 83;
const KEY_D = 68;

var mouseX = 0;
var mouseY = 0;

function setupInput() {
	//Jeffery Cen 20510562
	//Assignment Three for GBDA 301
	//Racing game with five ways of wellbeing theme	
	canvas.addEventListener('mousemove', updateMousePos);

	//Record key being pressed and release as action
	document.addEventListener('keydown', keyPressed);
	document.addEventListener('keyup', keyReleased);

	//WASD as input
	greenCar.setupInput(KEY_W, KEY_D, KEY_S, KEY_A);
	//Arrow key as input
	blueCar.setupInput(KEY_UP_ARROW, KEY_RIGHT_ARROW, KEY_DOWN_ARROW, KEY_LEFT_ARROW);
} 

function updateMousePos(evt) {
	//Mouse POsition, used for testing
	var rect = canvas.getBoundingClientRect();
	var root = document.documentElement;

	mouseX = evt.clientX - rect.left - root.scrollLeft;
	mouseY = evt.clientY - rect.top - root.scrollTop;

}

function keySet(keyEvent, whichCar, setTo) {
	//When key is pressed, set what event corresponds to it
	if(keyEvent.keyCode == whichCar.controlKeyLeft) {
		whichCar.keyHeld_TurnLeft = setTo;
	}
	if(keyEvent.keyCode == whichCar.controlKeyRight) {
		whichCar.keyHeld_TurnRight = setTo;
	}
	if(keyEvent.keyCode == whichCar.controlKeyUp) {
		whichCar.keyHeld_Gas = setTo;
	}
	if(keyEvent.keyCode == whichCar.controlKeyDown) {
		whichCar.keyHeld_Reverse = setTo;
	}
}

function keyPressed(evt) {
	//When pressed shit happens
	keySet(evt, greenCar, true);
	keySet(evt, blueCar, true);

	evt.preventDefault();
}

function keyReleased(evt) {
	//when released it stops happening
	keySet(evt, greenCar, false);
	keySet(evt, blueCar, false);
}